SPECIAL COMMAND: in Mobaxterm

Making .tar file:

tar -cvf BNF-Rupsa-0704.tar *.py *.png *.txt *.docx


untar the tar file:

tar -xvf BNF-Rupsa-0704.tar 

check the output file:

cat output_0704.txt

#### Special notes:

In the BNF-Rupsa-0704.tar file, I have attached 
a>.png files and 
b> .docx file (expression tree images) for better visualization.

check the .png files: command in Mobaxterm:

eog tree_image_1.png
eog tree_image_2.png
eog tree_image_3.png
eog tree_image_4.png 

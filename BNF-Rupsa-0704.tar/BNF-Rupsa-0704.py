#!/usr/bin/env python
# coding: utf-8

# In[2]:


import turtle
import sys
from PIL import Image

# Data structure to represent the expression tree
class ExpressionTreeNode:
    def __init__(self, val, left=None, right=None, expr_str=None):
        self.val = val
        self.left = left
        self.right = right
        self.expr_str = expr_str  # Store the expression string at each node

# Updated Tokenizer function
def tokenize(expr):
    tokens = []
    current_token = ""
    for char in expr:
        if char in "0123456789":
            current_token += char
        else:
            if current_token:
                tokens.append(current_token)
                current_token = ""
            if char.strip():  # Skip whitespace characters
                tokens.append(char)
    if current_token:
        tokens.append(current_token)
    return tokens

# Recursive descent parser functions
def expression(tokens):
    # <expression> ::= <factor> * <expression> | <factor> / <expression> | <factor>
    factortree = factor(tokens)

    if tokens and tokens[0] in "*/":
        # <expression> ::= <factor> * <expression> | <factor> / <expression>
        operator = tokens.pop(0)  # Get the operator (* or /)
        rightexp = expression(tokens)
        exptree = ExpressionTreeNode(operator, factortree, rightexp)
        exptree.expr_str = factortree.expr_str + " " + operator + " " + rightexp.expr_str
    else:
        # <expression> ::= <factor>
        exptree = factortree

    return exptree

def factor(tokens):
    # <factor> ::= <term> + <factor> | <term> - <factor> | <term>
    termtree = term(tokens)

    if tokens and tokens[0] in "+-":
        # <factor> ::= <term> + <factor> | <term> - <factor>
        operator = tokens.pop(0)  # Get the operator (+ or -)
        rightfactor = factor(tokens)
        factortree = ExpressionTreeNode(operator, termtree, rightfactor)
        factortree.expr_str = termtree.expr_str + " " + operator + " " + rightfactor.expr_str
    else:
        # <factor> ::= <term>
        factortree = termtree

    return factortree

def term(tokens):
    # <term> ::= { <expression> } | <literal>
    if tokens and tokens[0] == "{":
        # <term> ::= { <expression> }
        tokens.pop(0)  # remove the "{"
        termtree = expression(tokens)
        if tokens and tokens[0] == "}":
            tokens.pop(0)  # remove the "}"
        else:
            raise ValueError("Missing '}' in the term.")
    else:
        # <term> ::= <literal>
        termtree = literal(tokens)

    return termtree

def literal(tokens):
    # <literal> ::= 0|1|2|3|4|5|6|7|8|9
    if not tokens or not tokens[0].isdigit():
        raise ValueError("Invalid literal.")
    literal_val = int(tokens[0])
    tokens.pop(0)  # remove the literal token

    # Create a new leaf node with the value and expression string
    node = ExpressionTreeNode(literal_val)
    node.expr_str = str(literal_val)  # Assign the expression string for the leaf node
    return node

def expression_tree_from_input(input_expr):
    tokens = tokenize(input_expr)
    exp_tree = expression(tokens)
    exp_tree.expr_str = input_expr  # Assign the expression string for the root node
    return exp_tree

def evaluate_expression_tree(root):
    if not root:
        return 0

    if not root.left and not root.right:
        return root.val

    left_val = evaluate_expression_tree(root.left)
    right_val = evaluate_expression_tree(root.right)

    if root.val == "+":
        return left_val + right_val
    elif root.val == "-":
        return left_val - right_val
    elif root.val == "*":
        return left_val * right_val
    elif root.val == "/":
        return left_val / right_val
    else:
        raise ValueError("Invalid expression tree node value.")
        
def draw_expression_tree_turtle(root, x, y, spacing=60, turtle_screen=None, save_path=None):
    if root:
        if not turtle_screen:
            turtle_screen = turtle.Screen()
            turtle_screen.tracer(0)  # Turn off animation to draw the whole tree at once
            turtle_screen.clear()

        # Draw the node value and the expression string
        turtle.penup()
        turtle.goto(x, y)
        turtle.pendown()

        if root.left is None and root.right is None:
            # Draw only the leaf node values (numbers)
            turtle.write(str(root.val), align="center", font=("Arial", 35, "normal"))
        else:
            # Draw the root node values (operators)
            turtle.write(root.val, align="center", font=("Arial", 50, "bold"))

        if root.left:
            draw_expression_tree_turtle(root.left, x - spacing, y - spacing, spacing, turtle_screen=turtle_screen, save_path=save_path)
            turtle.penup()
            turtle.goto(x, y)
            turtle.pendown()
            turtle.goto(x - spacing, y - spacing)

        if root.right:
            draw_expression_tree_turtle(root.right, x + spacing, y - spacing, spacing, turtle_screen=turtle_screen, save_path=save_path)
            turtle.penup()
            turtle.goto(x, y)
            turtle.pendown()
            turtle.goto(x + spacing, y - spacing)

        turtle_screen.update()  # Update the turtle screen after drawing the tree
        
        if save_path:
            # Save the canvas as a PNG image
            canvas = turtle_screen.getcanvas()
            canvas.postscript(file=save_path)
            img = Image.open(save_path)
            img.save(save_path.replace('.ps', '.png'), 'png')

def node_to_string(node, depth=0):
    if not node:
        return ""
    
    # Create a string representation of the current node
    node_str = "  " * depth + str(node.val)

    # If the node has left and/or right children, add arcs
    if node.left or node.right:
        node_str += "\n" + "  " * (depth + 1) + "├─"
    if node.right:
        node_str += node_to_string(node.right, depth + 1)
        if node.left:
            node_str += "\n" + "  " * (depth + 1) + "└─"
    if node.left:
        node_str += node_to_string(node.left, depth + 1)

    return node_str

def main():
    if len(sys.argv) != 3:
        print("Usage: python BNF-Rupsa-0704.py input_0704.txt output_0704.txt")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]

    with open(input_file, 'r') as f:
        input_data = f.read()

    # Split input expressions by newline
    input_expressions = input_data.strip().split('\n')

    turtle.speed(0)
    turtle.hideturtle()
    turtle.bgcolor("white")

    with open(output_file, 'w') as f:
        for i, input_expr in enumerate(input_expressions):
            input_expr = input_expr.strip()

            exp_tree = expression_tree_from_input(input_expr)  # Define exp_tree here

            # Calculate the x and y coordinates for drawing the current tree
            x_offset = i * 300  # Adjust the x position for each tree
            y_offset = 0  # Adjust the y position for each tree

            # Generate a unique filename for each tree image
            save_path = f"tree_image_{i+1}.png"

            # Create a new turtle screen and clear the previous canvas
            turtle_screen = turtle.Screen()
            turtle_screen.tracer(0)  # Turn off animation to draw the whole tree at once
            turtle_screen.clear()

            draw_expression_tree_turtle(exp_tree, x=-150 + x_offset, y=200 + y_offset, spacing=60, turtle_screen=turtle_screen, save_path=save_path)

            result = evaluate_expression_tree(exp_tree)

            # Convert the expression tree to a tree-like string representation with arcs
            tree_str = node_to_string(exp_tree)
            f.write("Expression Tree " + str(i+1) + ":\n")  # Add index to indicate expression number
            f.write(tree_str + "\n")
            f.write("Result: " + str(result) + "\n")

            print("Result of evaluating Expression", i+1, ":", result)

    # Keep the turtle window open until manually closed
    turtle.done()


if __name__ == "__main__":
    main()


# In[ ]:




